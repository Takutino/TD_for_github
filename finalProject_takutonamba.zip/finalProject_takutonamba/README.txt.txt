For my final project, I decided to create a gemstone-like object by implementing refraction and using differential equation.

The gemstone at the middle has refractive index ranging from 0.98 to 1.015.
The one at the right has fixed refractive index, 1.0.

Here are the points where I impelment the logic:

Define refractive index and sigma (trace-fs.glsl : L122~155)
Update the accumulative reflectance and let refraction happen (trace-fs.glsl : L188~213)

Here are also specifications for what objects they are:
quadrics[0] : A plane that has reflection property
quadrics[1] : A sphere that has refraction property, with refractive index 0.98 ~ 1.015 and sigma = (0.7, 0.0, 0.7)
quadrics[2] : A sphere that has refraction property, with refractive index 1.0 and sigma = (0.9, 0.0, 0.9)