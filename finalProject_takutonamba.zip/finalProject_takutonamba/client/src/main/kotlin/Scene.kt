import org.w3c.dom.HTMLCanvasElement
import org.khronos.webgl.WebGLRenderingContext as GL
import org.khronos.webgl.Float32Array
import vision.gears.webglmath.UniformProvider
import vision.gears.webglmath.Vec3
import vision.gears.webglmath.Mat4
import kotlin.js.Date

class Scene (
  val gl : WebGL2RenderingContext) : UniformProvider("scene") {

  val vsQuad = Shader(gl, GL.VERTEX_SHADER, "quad-vs.glsl")
  val fsTrace = Shader(gl, GL.FRAGMENT_SHADER, "trace-fs.glsl")    
  val traceProgram = Program(gl, vsQuad, fsTrace)  
  val quadGeometry = TexturedQuadGeometry(gl)

  val traceMaterial = Material(traceProgram)

  val environmentTextureCube =       TextureCube(gl, 
        "media/sky/bluecloud_bk.jpg", //right
        "media/sky/bluecloud_ft.jpg", //left
        "media/sky/bluecloud_dn.jpg", //up
        "media/sky/bluecloud_up.jpg", //down
        "media/sky/bluecloud_lf.jpg", //back
        "media/sky/bluecloud_rt.jpg"  //front
        )

  init{
    traceMaterial["environment"]?.set(environmentTextureCube)
  }
  val traceMesh = Mesh(traceMaterial, quadGeometry)

  val camera = PerspectiveCamera(*Program.all)

  val timeAtFirstFrame = Date().getTime()
  var timeAtLastFrame =  timeAtFirstFrame

  init{
    addComponentsAndGatherUniforms(*Program.all)
  }

  val lights = Array<Light>(2) { Light(it, *Program.all) }
  init{
    lights[0].position.set(1.0f, 1.0f, 1.0f, 0.0f).normalize();
    lights[0].powerDensity.set(1.0f, 1.0f, 1.0f);
    lights[1].position.set(10.0f, 10.0f, -5.0f, 1.0f);
    lights[1].powerDensity.set(0.0f, 10000.0f, 0.0f);
  }

  val quadrics = Array<Quadric>(3) { Quadric(it, *Program.all) }
  init{
  	quadrics[0].surface.set(
  		1.0f, 0.0f, 0.0f, 0.0f,
  		0.0f, 2.0f, 0.0f, 0.0f,
  		0.0f, 0.0f, 1.0f, 0.0f,
  		0.0f, 0.0f, 0.0f, -16.0f
  		)
    QuadraticMat4(quadrics[0].surface).transform( Mat4().translate(0.0f, 10.0f) )

  	quadrics[0].clipper.set(
  		0.0f, 0.0f, 0.0f, 0.0f,
  		0.0f, 0.0f, 0.0f, 0.0f,
  		0.0f, 0.0f, 0.0f, 0.0f,
  		0.0f, 0.0f, 0.0f, 0.0f
  		)

    quadrics[0].clipper_second.set(
      0.0f, 0.0f, 0.0f, 0.0f,
      0.0f, 0.0f, 0.0f, 0.0f,
      0.0f, 0.0f, 0.0f, 0.0f,
      0.0f, 0.0f, 0.0f, 0.0f
      )
    QuadraticMat4(quadrics[0].clipper).transform( Mat4().translate(0.0f, 15.0f) )
    QuadraticMat4(quadrics[0].clipper_second).transform( Mat4().translate(0.0f) )

    quadrics[1].surface.set(
      1.0f, 0.0f, 0.0f, 0.0f,
      0.0f, 2.0f, 0.0f, 0.0f,
      0.0f, 0.0f, 1.0f, 0.0f,
      0.0f, 0.0f, 0.0f, -4.0f
      )
    QuadraticMat4(quadrics[1].surface).transform( Mat4().translate(5.0f, 10.0f, 8.0f) )

    quadrics[1].clipper.set(
      0.0f, 0.0f, 0.0f, 0.0f,
      0.0f, 0.0f, 0.0f, 0.0f,
      0.0f, 0.0f, 0.0f, 0.0f,
      0.0f, 0.0f, 0.0f, 0.0f
      )

    quadrics[1].clipper_second.set(
      0.0f, 0.0f, 0.0f, 0.0f,
      0.0f, 0.0f, 0.0f, 0.0f,
      0.0f, 0.0f, 0.0f, 0.0f,
      0.0f, 0.0f, 0.0f, 0.0f
      )
    QuadraticMat4(quadrics[1].clipper).transform( Mat4().translate(0.0f, 15.0f) )
    QuadraticMat4(quadrics[1].clipper_second).transform( Mat4().translate(0.0f) )

  	quadrics[2].surface.set(
  		0.0f, 0.0f, 0.0f, 0.0f,
  		0.0f, 0.0f, 0.0f, 1.0f,
  		0.0f, 0.0f, 0.0f, 0.0f,
  		0.0f, 0.0f, 0.0f, -1.0f
  		)
  	QuadraticMat4(quadrics[2].surface).transform( Mat4().translate(-2.0f, 5.0f) )
1
  	quadrics[2].clipper.set(
  		1.0f, 0.0f, 0.0f, 0.0f,
  		0.0f, 0.0f, 0.0f, 0.0f,
  		0.0f, 0.0f, 0.0f, 0.0f,
  		0.0f, 0.0f, 0.0f, -160.0f
  		)
  	quadrics[2].clipper_second.set(
  		0.0f, 0.0f, 0.0f, 0.0f,
  		0.0f, 0.0f, 0.0f, 0.0f,
  		0.0f, 0.0f, 1.0f, 0.0f,
  		0.0f, 0.0f, 0.0f, -160.0f
  		)
  	quadrics[2].color.set(0.75f, 0.75f, 0.75f, 0.0f)

  }

  fun resize(gl : WebGL2RenderingContext, canvas : HTMLCanvasElement) {
    gl.viewport(0, 0, canvas.width, canvas.height)
    camera.setAspectRatio(canvas.width.toFloat() / canvas.height.toFloat())
  }

  @Suppress("UNUSED_PARAMETER")
  fun update(gl : WebGL2RenderingContext, keysPressed : Set<String>) {

    val timeAtThisFrame = Date().getTime() 
    val dt = (timeAtThisFrame - timeAtLastFrame).toFloat() / 1000.0f
    val t  = (timeAtThisFrame - timeAtFirstFrame).toFloat() / 1000.0f    
    timeAtLastFrame = timeAtThisFrame

    camera.move(dt, keysPressed)

    // clear the screen
    gl.clearColor(0.3f, 0.0f, 0.3f, 1.0f)
    gl.clearDepth(1.0f)
    gl.clear(GL.COLOR_BUFFER_BIT or GL.DEPTH_BUFFER_BIT)

    traceMesh.draw( camera, *lights, *quadrics )
  }
}
