import vision.gears.webglmath.UniformProvider
import vision.gears.webglmath.Mat4
import vision.gears.webglmath.Vec4

class Quadric(
	id : Int, 
	vararg programs : Program) 
	: UniformProvider("quadrics[$id]") {

  val surface by Mat4() 
  val clipper by Mat4()
  val clipper_second by Mat4(
  	0.0f, 0.0f, 0.0f, 0.0f,
  	0.0f, 0.0f, 0.0f, 0.0f,
  	0.0f, 0.0f, 0.0f, 0.0f,
  	0.0f, 0.0f, 0.0f, 0.0f
  	)
  val color by Vec4(0.0f, 0.0f, 0.0f, 0.0f)

  init{
    addComponentsAndGatherUniforms(*programs)
  }
}


